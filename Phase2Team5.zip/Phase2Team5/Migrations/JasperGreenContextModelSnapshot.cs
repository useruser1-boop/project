﻿using System;
using JasperGreen.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

#nullable disable

namespace JasperGreen.Migrations
{
    [DbContext(typeof(JasperGreenContext))]
    partial class JasperGreenContextModelSnapshot : ModelSnapshot
    {
        protected override void BuildModel(ModelBuilder modelBuilder)
        {
#pragma warning disable 612, 618
            modelBuilder
                .HasAnnotation("ProductVersion", "9.0.10")
                .HasAnnotation("Relational:MaxIdentifierLength", 128);

            SqlServerModelBuilderExtensions.UseIdentityColumns(modelBuilder);

            modelBuilder.Entity("JasperGreen.Models.Crew", b =>
                {
                    b.Property<int>("CrewID")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("int");

                    SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("CrewID"));

                    b.Property<int>("CrewForemanID")
                        .HasColumnType("int");

                    b.Property<int>("CrewMember1ID")
                        .HasColumnType("int");

                    b.Property<int>("CrewMember2ID")
                        .HasColumnType("int");

                    b.Property<string>("CrewName")
                        .IsRequired()
                        .HasMaxLength(50)
                        .HasColumnType("nvarchar(50)");

                    b.HasKey("CrewID");

                    b.HasIndex("CrewForemanID");

                    b.HasIndex("CrewMember1ID");

                    b.HasIndex("CrewMember2ID");

                    b.ToTable("Crews");

                    b.HasData(
                        new
                        {
                            CrewID = 1,
                            CrewForemanID = 1,
                            CrewMember1ID = 2,
                            CrewMember2ID = 3,
                            CrewName = "Crew Alpha"
                        },
                        new
                        {
                            CrewID = 2,
                            CrewForemanID = 4,
                            CrewMember1ID = 5,
                            CrewMember2ID = 6,
                            CrewName = "Crew Bravo"
                        },
                        new
                        {
                            CrewID = 3,
                            CrewForemanID = 7,
                            CrewMember1ID = 8,
                            CrewMember2ID = 9,
                            CrewName = "Crew Charlie"
                        },
                        new
                        {
                            CrewID = 4,
                            CrewForemanID = 10,
                            CrewMember1ID = 11,
                            CrewMember2ID = 12,
                            CrewName = "Crew Delta"
                        },
                        new
                        {
                            CrewID = 5,
                            CrewForemanID = 13,
                            CrewMember1ID = 14,
                            CrewMember2ID = 15,
                            CrewName = "Crew Echo"
                        });
                });

            modelBuilder.Entity("JasperGreen.Models.Customer", b =>
                {
                    b.Property<int>("CustomerID")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("int");

                    SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("CustomerID"));

                    b.Property<string>("BillingAddress")
                        .HasMaxLength(100)
                        .HasColumnType("nvarchar(100)");

                    b.Property<string>("BillingCity")
                        .HasMaxLength(50)
                        .HasColumnType("nvarchar(50)");

                    b.Property<string>("BillingState")
                        .HasMaxLength(2)
                        .HasColumnType("nvarchar(2)");

                    b.Property<string>("BillingZIP")
                        .HasMaxLength(10)
                        .HasColumnType("nvarchar(10)");

                    b.Property<string>("CustomerPhone")
                        .HasMaxLength(20)
                        .HasColumnType("nvarchar(20)");

                    b.Property<string>("Email")
                        .HasMaxLength(100)
                        .HasColumnType("nvarchar(100)");

                    b.Property<string>("FirstName")
                        .IsRequired()
                        .HasMaxLength(50)
                        .HasColumnType("nvarchar(50)");

                    b.Property<string>("LastName")
                        .IsRequired()
                        .HasMaxLength(50)
                        .HasColumnType("nvarchar(50)");

                    b.HasKey("CustomerID");

                    b.ToTable("Customers");

                    b.HasData(
                        new
                        {
                            CustomerID = 1,
                            BillingAddress = "2101 Longmire Dr",
                            BillingCity = "College Station",
                            BillingState = "TX",
                            BillingZIP = "77845",
                            CustomerPhone = "9795551122",
                            Email = "maria.garcia@example.com",
                            FirstName = "Maria",
                            LastName = "Garcia"
                        },
                        new
                        {
                            CustomerID = 2,
                            BillingAddress = "4203 Rock Prairie Rd",
                            BillingCity = "College Station",
                            BillingState = "TX",
                            BillingZIP = "77845",
                            CustomerPhone = "9795552233",
                            Email = "d.nguyen@example.com",
                            FirstName = "Derek",
                            LastName = "Nguyen"
                        },
                        new
                        {
                            CustomerID = 3,
                            BillingAddress = "1708 Deacon Dr",
                            BillingCity = "College Station",
                            BillingState = "TX",
                            BillingZIP = "77840",
                            CustomerPhone = "9795553344",
                            Email = "sreed@example.com",
                            FirstName = "Samantha",
                            LastName = "Reed"
                        },
                        new
                        {
                            CustomerID = 4,
                            BillingAddress = "3315 Barron Rd",
                            BillingCity = "College Station",
                            BillingState = "TX",
                            BillingZIP = "77845",
                            CustomerPhone = "9795554455",
                            Email = "thughes@example.com",
                            FirstName = "Tyler",
                            LastName = "Hughes"
                        },
                        new
                        {
                            CustomerID = 5,
                            BillingAddress = "805 Southwest Pkwy E",
                            BillingCity = "College Station",
                            BillingState = "TX",
                            BillingZIP = "77840",
                            CustomerPhone = "9795555566",
                            Email = "apatel@example.com",
                            FirstName = "Alyssa",
                            LastName = "Patel"
                        });
                });

            modelBuilder.Entity("JasperGreen.Models.Employee", b =>
                {
                    b.Property<int>("EmployeeID")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("int");

                    SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("EmployeeID"));

                    b.Property<string>("EmployeeFirstName")
                        .IsRequired()
                        .HasMaxLength(50)
                        .HasColumnType("nvarchar(50)");

                    b.Property<string>("EmployeeLastName")
                        .IsRequired()
                        .HasMaxLength(50)
                        .HasColumnType("nvarchar(50)");

                    b.Property<DateTime>("HireDate")
                        .HasColumnType("datetime2");

                    b.Property<decimal>("HourlyRate")
                        .HasColumnType("decimal(10,2)");

                    b.Property<string>("JobTitle")
                        .IsRequired()
                        .HasMaxLength(50)
                        .HasColumnType("nvarchar(50)");

                    b.Property<string>("SSN")
                        .IsRequired()
                        .HasMaxLength(11)
                        .HasColumnType("nvarchar(11)");

                    b.HasKey("EmployeeID");

                    b.ToTable("Employees");

                    b.HasData(
                        new
                        {
                            EmployeeID = 1,
                            EmployeeFirstName = "Jose",
                            EmployeeLastName = "Lopez",
                            HireDate = new DateTime(2021, 2, 10, 0, 0, 0, 0, DateTimeKind.Unspecified),
                            HourlyRate = 18.00m,
                            JobTitle = "Crew Foreman",
                            SSN = "123-45-6001"
                        },
                        new
                        {
                            EmployeeID = 2,
                            EmployeeFirstName = "Emma",
                            EmployeeLastName = "Brooks",
                            HireDate = new DateTime(2021, 6, 3, 0, 0, 0, 0, DateTimeKind.Unspecified),
                            HourlyRate = 15.00m,
                            JobTitle = "Crew Member",
                            SSN = "123-45-6002"
                        },
                        new
                        {
                            EmployeeID = 3,
                            EmployeeFirstName = "Malik",
                            EmployeeLastName = "Turner",
                            HireDate = new DateTime(2022, 1, 14, 0, 0, 0, 0, DateTimeKind.Unspecified),
                            HourlyRate = 15.00m,
                            JobTitle = "Crew Member",
                            SSN = "123-45-6003"
                        },
                        new
                        {
                            EmployeeID = 4,
                            EmployeeFirstName = "Olivia",
                            EmployeeLastName = "Santos",
                            HireDate = new DateTime(2020, 9, 22, 0, 0, 0, 0, DateTimeKind.Unspecified),
                            HourlyRate = 18.00m,
                            JobTitle = "Crew Foreman",
                            SSN = "123-45-6004"
                        },
                        new
                        {
                            EmployeeID = 5,
                            EmployeeFirstName = "Noah",
                            EmployeeLastName = "Campbell",
                            HireDate = new DateTime(2023, 3, 5, 0, 0, 0, 0, DateTimeKind.Unspecified),
                            HourlyRate = 15.00m,
                            JobTitle = "Crew Member",
                            SSN = "123-45-6005"
                        },
                        new
                        {
                            EmployeeID = 6,
                            EmployeeFirstName = "Jasmine",
                            EmployeeLastName = "Kim",
                            HireDate = new DateTime(2019, 7, 18, 0, 0, 0, 0, DateTimeKind.Unspecified),
                            HourlyRate = 15.50m,
                            JobTitle = "Crew Member",
                            SSN = "123-45-6006"
                        },
                        new
                        {
                            EmployeeID = 7,
                            EmployeeFirstName = "Carter",
                            EmployeeLastName = "Mills",
                            HireDate = new DateTime(2024, 1, 9, 0, 0, 0, 0, DateTimeKind.Unspecified),
                            HourlyRate = 18.00m,
                            JobTitle = "Crew Foreman",
                            SSN = "123-45-6007"
                        },
                        new
                        {
                            EmployeeID = 8,
                            EmployeeFirstName = "Ava",
                            EmployeeLastName = "Ramirez",
                            HireDate = new DateTime(2022, 8, 30, 0, 0, 0, 0, DateTimeKind.Unspecified),
                            HourlyRate = 15.00m,
                            JobTitle = "Crew Member",
                            SSN = "123-45-6008"
                        },
                        new
                        {
                            EmployeeID = 9,
                            EmployeeFirstName = "Logan",
                            EmployeeLastName = "Howard",
                            HireDate = new DateTime(2020, 4, 12, 0, 0, 0, 0, DateTimeKind.Unspecified),
                            HourlyRate = 15.50m,
                            JobTitle = "Crew Member",
                            SSN = "123-45-6009"
                        },
                        new
                        {
                            EmployeeID = 10,
                            EmployeeFirstName = "Mia",
                            EmployeeLastName = "Bell",
                            HireDate = new DateTime(2023, 11, 2, 0, 0, 0, 0, DateTimeKind.Unspecified),
                            HourlyRate = 18.00m,
                            JobTitle = "Crew Foreman",
                            SSN = "123-45-6010"
                        },
                        new
                        {
                            EmployeeID = 11,
                            EmployeeFirstName = "Ethan",
                            EmployeeLastName = "Parker",
                            HireDate = new DateTime(2018, 12, 1, 0, 0, 0, 0, DateTimeKind.Unspecified),
                            HourlyRate = 16.00m,
                            JobTitle = "Crew Member",
                            SSN = "123-45-6011"
                        },
                        new
                        {
                            EmployeeID = 12,
                            EmployeeFirstName = "Grace",
                            EmployeeLastName = "Diaz",
                            HireDate = new DateTime(2024, 5, 15, 0, 0, 0, 0, DateTimeKind.Unspecified),
                            HourlyRate = 15.00m,
                            JobTitle = "Crew Member",
                            SSN = "123-45-6012"
                        },
                        new
                        {
                            EmployeeID = 13,
                            EmployeeFirstName = "Lucas",
                            EmployeeLastName = "Wright",
                            HireDate = new DateTime(2021, 10, 8, 0, 0, 0, 0, DateTimeKind.Unspecified),
                            HourlyRate = 18.50m,
                            JobTitle = "Crew Foreman",
                            SSN = "123-45-6013"
                        },
                        new
                        {
                            EmployeeID = 14,
                            EmployeeFirstName = "Harper",
                            EmployeeLastName = "Jenkins",
                            HireDate = new DateTime(2019, 2, 25, 0, 0, 0, 0, DateTimeKind.Unspecified),
                            HourlyRate = 15.50m,
                            JobTitle = "Crew Member",
                            SSN = "123-45-6014"
                        },
                        new
                        {
                            EmployeeID = 15,
                            EmployeeFirstName = "Mason",
                            EmployeeLastName = "Foster",
                            HireDate = new DateTime(2024, 10, 6, 0, 0, 0, 0, DateTimeKind.Unspecified),
                            HourlyRate = 15.00m,
                            JobTitle = "Crew Member",
                            SSN = "123-45-6015"
                        });
                });

            modelBuilder.Entity("JasperGreen.Models.Payment", b =>
                {
                    b.Property<int>("PaymentID")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("int");

                    SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("PaymentID"));

                    b.Property<int>("CustomerID")
                        .HasColumnType("int");

                    b.Property<decimal>("PaymentAmount")
                        .HasColumnType("decimal(10,2)");

                    b.Property<DateTime>("PaymentDate")
                        .HasColumnType("datetime2");

                    b.HasKey("PaymentID");

                    b.HasIndex("CustomerID");

                    b.ToTable("Payments");

                    b.HasData(
                        new
                        {
                            PaymentID = 1,
                            CustomerID = 1,
                            PaymentAmount = 125m,
                            PaymentDate = new DateTime(2025, 1, 7, 0, 0, 0, 0, DateTimeKind.Unspecified)
                        },
                        new
                        {
                            PaymentID = 2,
                            CustomerID = 1,
                            PaymentAmount = 110m,
                            PaymentDate = new DateTime(2025, 1, 14, 0, 0, 0, 0, DateTimeKind.Unspecified)
                        },
                        new
                        {
                            PaymentID = 3,
                            CustomerID = 2,
                            PaymentAmount = 145m,
                            PaymentDate = new DateTime(2025, 1, 21, 0, 0, 0, 0, DateTimeKind.Unspecified)
                        },
                        new
                        {
                            PaymentID = 4,
                            CustomerID = 2,
                            PaymentAmount = 115m,
                            PaymentDate = new DateTime(2025, 1, 28, 0, 0, 0, 0, DateTimeKind.Unspecified)
                        },
                        new
                        {
                            PaymentID = 5,
                            CustomerID = 3,
                            PaymentAmount = 100m,
                            PaymentDate = new DateTime(2025, 2, 6, 0, 0, 0, 0, DateTimeKind.Unspecified)
                        });
                });

            modelBuilder.Entity("JasperGreen.Models.Property", b =>
                {
                    b.Property<int>("PropertyID")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("int");

                    SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("PropertyID"));

                    b.Property<int>("CustomerID")
                        .HasColumnType("int");

                    b.Property<string>("PropertyAddress")
                        .IsRequired()
                        .HasMaxLength(100)
                        .HasColumnType("nvarchar(100)");

                    b.Property<string>("PropertyCity")
                        .IsRequired()
                        .HasMaxLength(50)
                        .HasColumnType("nvarchar(50)");

                    b.Property<string>("PropertyState")
                        .IsRequired()
                        .HasMaxLength(2)
                        .HasColumnType("nvarchar(2)");

                    b.Property<string>("PropertyZIP")
                        .IsRequired()
                        .HasMaxLength(10)
                        .HasColumnType("nvarchar(10)");

                    b.Property<decimal>("ServiceFee")
                        .HasColumnType("decimal(10,2)");

                    b.HasKey("PropertyID");

                    b.HasIndex("CustomerID");

                    b.ToTable("Properties");

                    b.HasData(
                        new
                        {
                            PropertyID = 1,
                            CustomerID = 1,
                            PropertyAddress = "2101 Longmire Dr",
                            PropertyCity = "College Station",
                            PropertyState = "TX",
                            PropertyZIP = "77845",
                            ServiceFee = 120m
                        },
                        new
                        {
                            PropertyID = 2,
                            CustomerID = 1,
                            PropertyAddress = "2205 Longmire Ct",
                            PropertyCity = "College Station",
                            PropertyState = "TX",
                            PropertyZIP = "77845",
                            ServiceFee = 105m
                        },
                        new
                        {
                            PropertyID = 3,
                            CustomerID = 2,
                            PropertyAddress = "4203 Rock Prairie Rd",
                            PropertyCity = "College Station",
                            PropertyState = "TX",
                            PropertyZIP = "77845",
                            ServiceFee = 140m
                        },
                        new
                        {
                            PropertyID = 4,
                            CustomerID = 2,
                            PropertyAddress = "1512 Birmingham Dr",
                            PropertyCity = "College Station",
                            PropertyState = "TX",
                            PropertyZIP = "77845",
                            ServiceFee = 110m
                        },
                        new
                        {
                            PropertyID = 5,
                            CustomerID = 3,
                            PropertyAddress = "1708 Deacon Dr",
                            PropertyCity = "College Station",
                            PropertyState = "TX",
                            PropertyZIP = "77840",
                            ServiceFee = 98m
                        },
                        new
                        {
                            PropertyID = 6,
                            CustomerID = 3,
                            PropertyAddress = "1801 Harvey Mitchell Pkwy S",
                            PropertyCity = "College Station",
                            PropertyState = "TX",
                            PropertyZIP = "77840",
                            ServiceFee = 125m
                        },
                        new
                        {
                            PropertyID = 7,
                            CustomerID = 4,
                            PropertyAddress = "3315 Barron Rd",
                            PropertyCity = "College Station",
                            PropertyState = "TX",
                            PropertyZIP = "77845",
                            ServiceFee = 130m
                        },
                        new
                        {
                            PropertyID = 8,
                            CustomerID = 4,
                            PropertyAddress = "3410 Finch Ln",
                            PropertyCity = "College Station",
                            PropertyState = "TX",
                            PropertyZIP = "77845",
                            ServiceFee = 115m
                        },
                        new
                        {
                            PropertyID = 9,
                            CustomerID = 5,
                            PropertyAddress = "3910 Copperfield Dr",
                            PropertyCity = "Bryan",
                            PropertyState = "TX",
                            PropertyZIP = "77807",
                            ServiceFee = 95m
                        },
                        new
                        {
                            PropertyID = 10,
                            CustomerID = 5,
                            PropertyAddress = "1820 Briarcrest Dr",
                            PropertyCity = "Bryan",
                            PropertyState = "TX",
                            PropertyZIP = "77802",
                            ServiceFee = 108m
                        });
                });

            modelBuilder.Entity("JasperGreen.Models.ProvideService", b =>
                {
                    b.Property<int>("ServiceID")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("int");

                    SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("ServiceID"));

                    b.Property<int>("CrewID")
                        .HasColumnType("int");

                    b.Property<int>("CustomerID")
                        .HasColumnType("int");

                    b.Property<int?>("PaymentID")
                        .HasColumnType("int");

                    b.Property<int>("PropertyID")
                        .HasColumnType("int");

                    b.Property<DateTime>("ServiceDate")
                        .HasColumnType("datetime2");

                    b.Property<decimal>("ServiceFee")
                        .HasColumnType("decimal(10,2)");

                    b.HasKey("ServiceID");

                    b.HasIndex("CrewID");

                    b.HasIndex("CustomerID");

                    b.HasIndex("PaymentID");

                    b.HasIndex("PropertyID");

                    b.ToTable("ProvideServices");

                    b.HasData(
                        new
                        {
                            ServiceID = 1,
                            CrewID = 1,
                            CustomerID = 1,
                            PaymentID = 1,
                            PropertyID = 1,
                            ServiceDate = new DateTime(2025, 1, 5, 0, 0, 0, 0, DateTimeKind.Unspecified),
                            ServiceFee = 125m
                        },
                        new
                        {
                            ServiceID = 2,
                            CrewID = 3,
                            CustomerID = 1,
                            PaymentID = 2,
                            PropertyID = 2,
                            ServiceDate = new DateTime(2025, 1, 12, 0, 0, 0, 0, DateTimeKind.Unspecified),
                            ServiceFee = 110m
                        },
                        new
                        {
                            ServiceID = 3,
                            CrewID = 2,
                            CustomerID = 2,
                            PaymentID = 3,
                            PropertyID = 3,
                            ServiceDate = new DateTime(2025, 1, 18, 0, 0, 0, 0, DateTimeKind.Unspecified),
                            ServiceFee = 145m
                        },
                        new
                        {
                            ServiceID = 4,
                            CrewID = 4,
                            CustomerID = 2,
                            PaymentID = 4,
                            PropertyID = 4,
                            ServiceDate = new DateTime(2025, 1, 25, 0, 0, 0, 0, DateTimeKind.Unspecified),
                            ServiceFee = 115m
                        },
                        new
                        {
                            ServiceID = 5,
                            CrewID = 1,
                            CustomerID = 3,
                            PaymentID = 5,
                            PropertyID = 5,
                            ServiceDate = new DateTime(2025, 2, 2, 0, 0, 0, 0, DateTimeKind.Unspecified),
                            ServiceFee = 100m
                        },
                        new
                        {
                            ServiceID = 6,
                            CrewID = 5,
                            CustomerID = 3,
                            PropertyID = 6,
                            ServiceDate = new DateTime(2025, 2, 10, 0, 0, 0, 0, DateTimeKind.Unspecified),
                            ServiceFee = 128m
                        },
                        new
                        {
                            ServiceID = 7,
                            CrewID = 2,
                            CustomerID = 4,
                            PropertyID = 7,
                            ServiceDate = new DateTime(2025, 2, 18, 0, 0, 0, 0, DateTimeKind.Unspecified),
                            ServiceFee = 132m
                        },
                        new
                        {
                            ServiceID = 8,
                            CrewID = 4,
                            CustomerID = 4,
                            PropertyID = 8,
                            ServiceDate = new DateTime(2025, 2, 26, 0, 0, 0, 0, DateTimeKind.Unspecified),
                            ServiceFee = 118m
                        },
                        new
                        {
                            ServiceID = 9,
                            CrewID = 5,
                            CustomerID = 5,
                            PropertyID = 9,
                            ServiceDate = new DateTime(2025, 3, 7, 0, 0, 0, 0, DateTimeKind.Unspecified),
                            ServiceFee = 98m
                        },
                        new
                        {
                            ServiceID = 10,
                            CrewID = 3,
                            CustomerID = 5,
                            PropertyID = 10,
                            ServiceDate = new DateTime(2025, 3, 15, 0, 0, 0, 0, DateTimeKind.Unspecified),
                            ServiceFee = 112m
                        });
                });

            modelBuilder.Entity("JasperGreen.Models.Crew", b =>
                {
                    b.HasOne("JasperGreen.Models.Employee", "CrewForeman")
                        .WithMany()
                        .HasForeignKey("CrewForemanID")
                        .OnDelete(DeleteBehavior.Restrict)
                        .IsRequired();

                    b.HasOne("JasperGreen.Models.Employee", "CrewMember1")
                        .WithMany()
                        .HasForeignKey("CrewMember1ID")
                        .OnDelete(DeleteBehavior.Restrict)
                        .IsRequired();

                    b.HasOne("JasperGreen.Models.Employee", "CrewMember2")
                        .WithMany()
                        .HasForeignKey("CrewMember2ID")
                        .OnDelete(DeleteBehavior.Restrict)
                        .IsRequired();

                    b.Navigation("CrewForeman");

                    b.Navigation("CrewMember1");

                    b.Navigation("CrewMember2");
                });

            modelBuilder.Entity("JasperGreen.Models.Payment", b =>
                {
                    b.HasOne("JasperGreen.Models.Customer", "Customer")
                        .WithMany()
                        .HasForeignKey("CustomerID")
                        .OnDelete(DeleteBehavior.Restrict)
                        .IsRequired();

                    b.Navigation("Customer");
                });

            modelBuilder.Entity("JasperGreen.Models.Property", b =>
                {
                    b.HasOne("JasperGreen.Models.Customer", "Customer")
                        .WithMany("Properties")
                        .HasForeignKey("CustomerID")
                        .OnDelete(DeleteBehavior.Cascade)
                        .IsRequired();

                    b.Navigation("Customer");
                });

            modelBuilder.Entity("JasperGreen.Models.ProvideService", b =>
                {
                    b.HasOne("JasperGreen.Models.Crew", "Crew")
                        .WithMany("ProvideServices")
                        .HasForeignKey("CrewID")
                        .OnDelete(DeleteBehavior.Restrict)
                        .IsRequired();

                    b.HasOne("JasperGreen.Models.Customer", "Customer")
                        .WithMany()
                        .HasForeignKey("CustomerID")
                        .OnDelete(DeleteBehavior.Restrict)
                        .IsRequired();

                    b.HasOne("JasperGreen.Models.Payment", "Payment")
                        .WithMany()
                        .HasForeignKey("PaymentID")
                        .OnDelete(DeleteBehavior.SetNull);

                    b.HasOne("JasperGreen.Models.Property", "Property")
                        .WithMany("ProvideServices")
                        .HasForeignKey("PropertyID")
                        .OnDelete(DeleteBehavior.Restrict)
                        .IsRequired();

                    b.Navigation("Crew");

                    b.Navigation("Customer");

                    b.Navigation("Payment");

                    b.Navigation("Property");
                });

            modelBuilder.Entity("JasperGreen.Models.Crew", b =>
                {
                    b.Navigation("ProvideServices");
                });

            modelBuilder.Entity("JasperGreen.Models.Customer", b =>
                {
                    b.Navigation("Properties");
                });

            modelBuilder.Entity("JasperGreen.Models.Property", b =>
                {
                    b.Navigation("ProvideServices");
                });
#pragma warning restore 612, 618
        }
    }
}
